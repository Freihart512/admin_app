// api-gateway/src/@shared/errors/repository.error.ts
export class RepositoryError extends Error { name = 'RepositoryError'; }
