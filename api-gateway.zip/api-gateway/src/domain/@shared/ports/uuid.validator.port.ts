export interface UuidValidatorPort {
  validate(uuid: string): boolean;
}
