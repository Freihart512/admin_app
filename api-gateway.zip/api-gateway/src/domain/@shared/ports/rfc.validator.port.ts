
export interface RFCValidatorPort {
    validate(rfc: string): boolean
  }
  