import { ValueObject } from '@domain/@shared/value-objects/base.value-object';
import { UUID } from '@domain/@shared/value-objects/uuid.value-object';
import { EmailAddress } from './email-address.value-object';
import { AccountStatus } from '../user.types';

export interface UserSummaryProps {
  id: UUID;
  name: string;
  lastName: string;
  email: EmailAddress;
  status: AccountStatus;
}

export class UserSummary extends ValueObject<UserSummaryProps> {
  private _id: UUID;
  private _name: string;
  private _lastName: string;
  private _email: EmailAddress;
  private _status: AccountStatus;

  private constructor(props: UserSummaryProps) {
    super(props);
    this._id = props.id;
    this._name = props.name;
    this._lastName = props.lastName;
    this._email = props.email;
    this._status = props.status;
  }

  public static create(props: UserSummaryProps): UserSummary {
    return new UserSummary(props);
  }

  get id(): UUID {
      return this._id;
  }

  get name(): string {
      return this._name;
  }

  get lastName(): string {
      return this._lastName;
  }

  get email(): EmailAddress {
      return this._email;
  }

  get status(): AccountStatus {
      return this._status;
  }

  protected ensureIsValid(value: UserSummaryProps): void {}
}
